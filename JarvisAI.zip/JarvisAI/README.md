# Jarvis AI (Android)

1. Install Android Studio (latest). File > Open > select this folder. Let Gradle sync finish.
   (If it says no Gradle wrapper, accept the prompt to use Gradle 8.7.)
2. Connect your phone (USB debugging on) or use an emulator with Google Play. Press Run.
3. In the app: paste your Anthropic API key (console.anthropic.com).
4. Tap "Enable Jarvis in Accessibility settings" > Jarvis > turn ON.
   If Android says "restricted setting": App info > ⋮ menu > Allow restricted settings, then retry.
5. Type or speak a command, e.g. "Open Settings and turn on Wi-Fi", then Run.
   Stop button halts it at any time.

Safety built in: confirmation popup before payments/messages/deleting/installing, never types
passwords/OTPs, 30-step limit.
