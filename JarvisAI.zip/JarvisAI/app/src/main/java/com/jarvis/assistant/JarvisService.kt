package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.ContextThemeWrapper
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class JarvisService : AccessibilityService() {

    companion object {
        var instance: JarvisService? = null
        const val MAX_SIDE = 1280f
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var job: Job? = null
    private var tts: TextToSpeech? = null

    val isRunning get() = job?.isActive == true

    override fun onServiceConnected() {
        instance = this
        tts = TextToSpeech(this) { tts?.language = Locale.getDefault() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        job?.cancel()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- entry points used by the UI ----------

    fun runCommand(apiKey: String, command: String, log: (String) -> Unit) {
        if (isRunning) { log("Already running a task. Press Stop first."); return }
        job = scope.launch {
            try {
                Agent(this@JarvisService, apiKey, log).run(command)
            } catch (e: CancellationException) {
                log("Stopped.")
            } catch (e: Exception) {
                log("Error: ${e.message}")
            }
        }
    }

    fun stop() { job?.cancel() }

    fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }

    // ---------- "eyes" ----------

    /** Returns base64 JPEG and the scale factor (screenshot px / real px). */
    suspend fun screenshot(): Pair<String, Float>? = suspendCoroutine { cont ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = result.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hw.close()
                    if (bmp == null) { cont.resume(null); return }
                    val scale = minOf(1f, MAX_SIDE / maxOf(bmp.width, bmp.height))
                    val scaled = if (scale < 1f)
                        Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
                    else bmp
                    val out = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
                    cont.resume(Pair(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), scale))
                } catch (e: Exception) { cont.resume(null) }
            }
            override fun onFailure(errorCode: Int) { cont.resume(null) }
        })
    }

    // ---------- "hands" ----------

    private suspend fun gesture(path: Path, duration: Long): Boolean = suspendCoroutine { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { cont.resume(false) }
        }, null)
        if (!ok) cont.resume(false)
    }

    suspend fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 60)

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) =
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, 350)

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun press(button: String): Boolean = when (button.lowercase()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "enter" -> {
            // Tap the keyboard's action key via IME action on focused field
            val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            node?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) ?: false
        }
        else -> false
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(name, ignoreCase = true)
        } ?: return false
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    fun openUri(uri: String): Boolean = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) { false }

    // ---------- safety: ask the human ----------

    suspend fun confirm(question: String): Boolean = suspendCoroutine { cont ->
        var done = false
        fun finish(v: Boolean) { if (!done) { done = true; cont.resume(v) } }
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert)
        val dlg = AlertDialog.Builder(ctx)
            .setTitle("Jarvis needs your OK")
            .setMessage(question)
            .setPositiveButton("Yes, proceed") { _, _ -> finish(true) }
            .setNegativeButton("No") { _, _ -> finish(false) }
            .setOnCancelListener { finish(false) }
            .create()
        dlg.window?.setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        dlg.show()
        speak(question)
    }
}
