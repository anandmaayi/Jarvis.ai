package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class Agent(
    private val svc: JarvisService,
    private val apiKey: String,
    private val log: (String) -> Unit
) {
    companion object {
        const val MODEL = "claude-sonnet-5-5"
        const val MAX_STEPS = 30

        val SYSTEM = """
You are Jarvis, an assistant that controls an Android phone for the user. Each turn you see a screenshot of the current screen.
Coordinates you give are pixels in the screenshot you are shown (top-left is 0,0).
Work step by step with ONE or a few tool calls at a time, then look at the new screenshot.
Prefer open_app / open_uri over hunting for icons. Use deep links when you know them, e.g.
  spotify:search:<query>, https://www.youtube.com/results?search_query=<query>, google.navigation:q=<place>, tel:<number>.
SAFETY RULES (strict):
- Before ANY payment, purchase, booking confirmation, sending a message/email, deleting data, or installing an app, call confirm_with_user and only continue if it returns yes.
- Never type passwords, OTPs, card numbers or PINs. If a login/OTP/payment/CAPTCHA screen needs them, call done and tell the user to finish that step.
- If the screen looks wrong or you are stuck after a few tries, call done and explain.
When the task is complete call done with a short spoken-style summary.
""".trimIndent()

        val TOOLS = """
[
 {"name":"tap","description":"Tap at screenshot coordinates.","input_schema":{"type":"object","properties":{"x":{"type":"number"},"y":{"type":"number"}},"required":["x","y"]}},
 {"name":"swipe","description":"Swipe/scroll from (x1,y1) to (x2,y2). To scroll down, swipe upward.","input_schema":{"type":"object","properties":{"x1":{"type":"number"},"y1":{"type":"number"},"x2":{"type":"number"},"y2":{"type":"number"}},"required":["x1","y1","x2","y2"]}},
 {"name":"type_text","description":"Type text into the focused input field (tap the field first). Replaces its contents.","input_schema":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
 {"name":"press","description":"Press a system button: back, home, recents, notifications, enter (submit/search).","input_schema":{"type":"object","properties":{"button":{"type":"string","enum":["back","home","recents","notifications","enter"]}},"required":["button"]}},
 {"name":"open_app","description":"Open an installed app by its name, e.g. 'Play Store', 'Spotify', 'WhatsApp'.","input_schema":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
 {"name":"open_uri","description":"Open a URL or deep link via Android intent.","input_schema":{"type":"object","properties":{"uri":{"type":"string"}},"required":["uri"]}},
 {"name":"wait","description":"Wait for seconds (e.g. while an app installs or a page loads).","input_schema":{"type":"object","properties":{"seconds":{"type":"number"}},"required":["seconds"]}},
 {"name":"confirm_with_user","description":"Ask the user yes/no before risky actions. Returns yes or no.","input_schema":{"type":"object","properties":{"question":{"type":"string"}},"required":["question"]}},
 {"name":"done","description":"Finish the task and tell the user the result.","input_schema":{"type":"object","properties":{"message":{"type":"string"}},"required":["message"]}}
]
""".trimIndent()
    }

    private val client = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
    private val messages = JSONArray()
    private var scale = 1f

    private fun text(t: String) = JSONObject().put("type", "text").put("text", t)
    private fun image(b64: String) = JSONObject().put("type", "image").put(
        "source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)
    )

    suspend fun run(command: String) {
        log("▶ $command")
        val shot = svc.screenshot()
        scale = shot?.second ?: 1f
        val first = JSONArray().put(text(command))
        shot?.let { first.put(image(it.first)) }
        messages.put(JSONObject().put("role", "user").put("content", first))

        for (step in 1..MAX_STEPS) {
            val resp = withContext(Dispatchers.IO) { callApi() }
            if (resp.has("error")) { log("API error: " + resp.getJSONObject("error").optString("message")); return }

            val content = resp.getJSONArray("content")
            messages.put(JSONObject().put("role", "assistant").put("content", content))

            val results = JSONArray()
            var finished = false
            var hadTool = false
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.getString("type") == "text") log("💬 " + b.getString("text"))
                if (b.getString("type") != "tool_use") continue
                hadTool = true
                val name = b.getString("name")
                val input = b.getJSONObject("input")
                log("🔧 $name $input")
                val out = execute(name, input)
                if (name == "done") finished = true
                results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id"))
                    .put("content", JSONArray().put(text(out))))
            }
            if (!hadTool || finished) return

            delay(1200)
            val shot2 = svc.screenshot()
            if (shot2 != null) {
                scale = shot2.second
                val last = results.getJSONObject(results.length() - 1).getJSONArray("content")
                last.put(text("Current screen:")).put(image(shot2.first))
            } else {
                log("(screenshot unavailable — app may block it)")
            }
            stripOldImages()
            messages.put(JSONObject().put("role", "user").put("content", results))
        }
        log("Reached the step limit ($MAX_STEPS). Stopping.")
        svc.speak("I reached my step limit.")
    }

    private suspend fun execute(name: String, a: JSONObject): String {
        return when (name) {
            "tap" -> if (svc.tap((a.getDouble("x") / scale).toFloat(), (a.getDouble("y") / scale).toFloat())) "tapped" else "tap failed"
            "swipe" -> if (svc.swipe(
                (a.getDouble("x1") / scale).toFloat(), (a.getDouble("y1") / scale).toFloat(),
                (a.getDouble("x2") / scale).toFloat(), (a.getDouble("y2") / scale).toFloat())) "swiped" else "swipe failed"
            "type_text" -> if (svc.typeText(a.getString("text"))) "typed" else "no editable field focused — tap the field first"
            "press" -> if (svc.press(a.getString("button"))) "pressed" else "press failed"
            "open_app" -> if (svc.openApp(a.getString("name"))) "opened" else "app not found"
            "open_uri" -> if (svc.openUri(a.getString("uri"))) "opened" else "could not open uri"
            "wait" -> { delay((a.getDouble("seconds").coerceIn(0.0, 30.0) * 1000).toLong()); "waited" }
            "confirm_with_user" -> if (svc.confirm(a.getString("question"))) "yes" else "no — the user declined; do not proceed"
            "done" -> { val m = a.getString("message"); log("✅ $m"); svc.speak(m); "ok" }
            else -> "unknown tool"
        }
    }

    /** Keep only the newest screenshot in history to save tokens. */
    private fun stripOldImages() {
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            if (m.getString("role") != "user") continue
            val c = m.getJSONArray("content")
            for (j in 0 until c.length()) {
                val blk = c.getJSONObject(j)
                if (blk.getString("type") == "image") { c.put(j, text("[old screenshot removed]")) }
                if (blk.getString("type") == "tool_result") {
                    val inner = blk.getJSONArray("content")
                    for (k in 0 until inner.length()) {
                        if (inner.getJSONObject(k).getString("type") == "image") inner.put(k, text("[old screenshot removed]"))
                    }
                }
            }
        }
    }

    private fun callApi(): JSONObject {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 1024)
            .put("system", SYSTEM)
            .put("tools", JSONArray(TOOLS))
            .put("messages", messages)
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            return JSONObject(r.body?.string() ?: "{\"error\":{\"message\":\"empty response\"}}")
        }
    }
}
