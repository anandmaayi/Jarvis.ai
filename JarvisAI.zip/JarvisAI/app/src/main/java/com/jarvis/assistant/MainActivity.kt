package com.jarvis.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class MainActivity : Activity() {

    private lateinit var keyBox: EditText
    private lateinit var cmdBox: EditText
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }

        root.addView(TextView(this).apply { text = "Jarvis"; textSize = 28f })

        keyBox = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        root.addView(keyBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "1. Enable Jarvis in Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        cmdBox = EditText(this).apply { hint = "Tell Jarvis what to do…" }
        root.addView(cmdBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "🎤 Speak"; setOnClickListener { listen() } })
        row.addView(Button(this).apply { text = "▶ Run"; setOnClickListener { run(prefs) } })
        row.addView(Button(this).apply {
            text = "⏹ Stop"
            setOnClickListener { JarvisService.instance?.stop() }
        })
        root.addView(row)

        logView = TextView(this).apply { textSize = 14f; setTextIsSelectable(true) }
        root.addView(ScrollView(this).apply { addView(logView) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun run(prefs: android.content.SharedPreferences) {
        val key = keyBox.text.toString().trim()
        val cmd = cmdBox.text.toString().trim()
        if (key.isEmpty() || cmd.isEmpty()) { toast("Enter API key and a command"); return }
        val svc = JarvisService.instance
        if (svc == null) { toast("Enable Jarvis in Accessibility settings first"); return }
        prefs.edit().putString("key", key).apply()
        logView.text = ""
        // Go to home screen so the user sees the phone being controlled.
        svc.runCommand(key, cmd) { line -> runOnUiThread { logView.append(line + "\n\n") } }
        moveTaskToBack(true)
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "What should I do?")
        }
        try { startActivityForResult(i, 1) } catch (e: Exception) { toast("Speech recognition not available") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
                cmdBox.setText(it)
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
